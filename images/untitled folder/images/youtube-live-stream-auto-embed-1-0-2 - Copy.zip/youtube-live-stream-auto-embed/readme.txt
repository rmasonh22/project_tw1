=== Youtube Live Stream Auto Embed ===
Contributors: sykemedia
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=7SCTYGSQ3R3ME
Author: Wordpress Youtube Live Stream
Link: http://www.wordpressyoutubelivestream.com/
Tags: YouTube, Videoplayer, Auto Embed, YouTube Live stream, Shortcode, live-streaming, API v3
Requires at least: 3.4
Tested up to: 4.2
Stable tag: 1.0.2
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Provides a shortcode to automatically embed the latest video or current live stream of a specified YouTube channel.

== Description ==

This Wordpress plugin provides a shortcode to automatically embed the latest video or current live stream of a specified YouTube channel. [youtube-live]
It comes with an options page to let you set the default options for YouTube channel. Height, Width, Responsive Player, Player Color and Autoplay.

When NOT streaming live automatically embed a YouTube Channels latest uploaded video/previous live event or Playlist.

How it works (<a href="http://www.wordpressyoutubelivestream.com/" target="_blank">View LIVE Demo</a>)

A. If you're currently live, automatically display the live video.

B. If you're not currently live, display the previous upload/live event.

Latest YouTube API V3.

== Installation ==

1. Upload the complete `youtube-live-stream-auto-embed` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to the plugins settings page located in in the settings tab of the Wordpress admin menu and setup your default settings
4. Paste the Youtube Live shortcode in a page or post [youtube-live]
5. ALL DONE!

**YouTube API Credentials**

1. Go to the Google Developers Console <a href="https://console.developers.google.com/project" target="_blank">www.console.developers.google.com/project</a>
2. Select a project, or create a new one
3. In the sidebar on the left, expand APIs & auth. Next, click APIs. In the list of APIs, make sure the status is ON for the YouTube Data API v3 by creating a new Public API access key.

**YouTube Channel ID Code**

1. Find your YouTube Channel ID by visting <a href="https://www.youtube.com/account_advanced" target="_blank">www.youtube.com/account_advanced</a>

**YouTube Channel Username**

1. To find you Channel Username go to YouTube and click on your Channel home page, the Channel Username will appear in the url bar of your web browser. 

== Frequently Asked Questions ==

= Is it possible to set the video start playing automatically when NOT streaming live? =

Yes that ability has now been added to the plugin, but YouTube does NOT count autoplay videos as views towards your videos view count. Only LIVE events play automatically and count as views.

== Screenshots ==

1. Auto embed youtube live stream with a shortcode
2. Youtube Live Stream Auto Embed settings page

== Changelog ==

= 1.0.2 =
* Plugin Upgrade August 4, 2015
* updated options for latest youtube player
* Added show html content when live
* Added show html content when not live

= 1.0.1 =
* Plugin Upgrade July 27, 2015
* Added more player options
* Added show latest video or playlist option

= 1.0.0 =
* Created June 29, 2015

== Upgrade Notice ==

= 1.0.2 =
Added New Feature.

= 1.0.1 =
Major Upgrade.

= 1.0.0 =
First version release.

== Credits ==
* [sykemedia](https://sykemedia.net/creative) - for plugin development
