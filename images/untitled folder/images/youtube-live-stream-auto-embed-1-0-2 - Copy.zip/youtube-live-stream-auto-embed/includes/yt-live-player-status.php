<?php

class YouTubeLiveStreamAutoEmbedStatus
{
	public $channelId;
	public $API_Key;
	public $jsonResponse; 
	public $objectResponse; 
	public $arrayRespone; 
	public $isLive; 
	public $queryData; 
	public $getAddress; 
	public $getQuery; 
	public $queryString; 
	public $part;
	public $eventType;
	public $type;
	public $embed_code; 
	public $live_video_id;
	public function __construct($ChannelID, $API_Key, $autoQuery = true)
	{
		$this->channelId = $ChannelID;
		$this->API_Key = $API_Key;
		$this->part = "id,snippet";
		$this->eventType = "live";
		$this->type = "video";
		$this->getAddress = "https://www.googleapis.com/youtube/v3/search?";
		if($autoQuery == true) { $this->queryIt(); }
	}
	public function queryIt()
	{
		$this->queryData = array(
			"part" => $this->part,
			"channelId" => $this->channelId,
			"eventType" => $this->eventType,
			"type" => $this->type,
			"key" => $this->API_Key,
		);
		$this->getQuery = http_build_query($this->queryData); 
		$this->queryString = $this->getAddress . $this->getQuery;
		$this->jsonResponse = file_get_contents($this->queryString); 
		$this->objectResponse = json_decode($this->jsonResponse); 
		$this->arrayResponse = json_decode($this->jsonResponse, TRUE); 
		$this->isLive();
		if($this->isLive)
		{
			$this->live_video_id = $this->objectResponse->items[0]->id->videoId;
			$this->embedCodeLiveOn();
		}
	}
	public function isLive($getOrNot = false)
	{
		if($getOrNot==true)
		{
			$this->queryIt();
		}
		$live_items = count($this->objectResponse->items);
		if($live_items>0)
		{
			$this->isLive = true;
			return true;
		}
		else
		{
			$this->isLive = false;
			return false;
		}
	}
	public function embedCodeLiveOn()
	{
		
		$this->embed_code_live_on = <<<EOT
		
EOT;

		return $this->embed_code_live_on;
	}
    
	public function embedCodeLiveOff()
	{
		
		$this->embed_code_live_off = <<<EOT
		
EOT;
		return $this->embed_code_live_off;
	}	
}
?>