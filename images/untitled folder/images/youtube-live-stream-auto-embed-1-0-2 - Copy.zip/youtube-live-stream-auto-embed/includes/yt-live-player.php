<?php

class YouTubeLiveStreamAutoEmbed
{
	public $channelId;
	public $API_Key;
	public $jsonResponse; 
	public $objectResponse; 
	public $arrayRespone; 
	public $isLive; 
	public $queryData; 
	public $getAddress; 
	public $getQuery; 
	public $queryString; 
	public $part;
	public $eventType;
	public $type;
	public $embed_code; 
	public $live_video_id;
	public function __construct($ChannelID, $API_Key, $autoQuery = true)
	{
		$this->channelId = $ChannelID;
		$this->API_Key = $API_Key;
		$this->part = "id,snippet";
		$this->eventType = "live";
		$this->type = "video";
		$this->getAddress = "https://www.googleapis.com/youtube/v3/search?";
		if($autoQuery == true) { $this->queryIt(); }
	}
	public function queryIt()
	{
		$this->queryData = array(
			"part" => $this->part,
			"channelId" => $this->channelId,
			"eventType" => $this->eventType,
			"type" => $this->type,
			"key" => $this->API_Key,
		);
		$this->getQuery = http_build_query($this->queryData); 
		$this->queryString = $this->getAddress . $this->getQuery;
		$this->jsonResponse = file_get_contents($this->queryString); 
		$this->objectResponse = json_decode($this->jsonResponse); 
		$this->arrayResponse = json_decode($this->jsonResponse, TRUE); 
		$this->isLive();
		if($this->isLive)
		{
			$this->live_video_id = $this->objectResponse->items[0]->id->videoId;
			$this->embedCodeOn();
		}
	}
	public function isLive($getOrNot = false)
	{
		if($getOrNot==true)
		{
			$this->queryIt();
		}
		$live_items = count($this->objectResponse->items);
		if($live_items>0)
		{
			$this->isLive = true;
			return true;
		}
		else
		{
			$this->isLive = false;
			return false;
		}
	}
	public function embedCodeOn()
	{
		
	$yt_player_width = "yt_width";
	$yt_player_height = "yt_height";
	$yt_player_autogo = "yt_autogo";
	$yt_player_controls_live = "yt_controls_live";
	$yt_player_title_live = "yt_title_live";
	$yt_player_autohide_live = "yt_autohide_live";
	$yt_player_theme = "yt_theme";
	$yt_player_color = "yt_color";
	$yt_player_vol = "yt_vol";
 
	if(isset($_POST["get"])){ 
	
    	$yt_width_show = $_POST[$yt_player_width];
    	$yt_height_show = $_POST[$yt_player_height]; 
		$yt_autogo_show = $_POST[$yt_player_autogo];
    	$yt_controls_show_live = $_POST[$yt_player_controls_live];
    	$yt_title_show_live = $_POST[$yt_player_title_live];
    	$yt_autohide_show_live = $_POST[$yt_player_autohide_live];
		$yt_theme_show = $_POST[$yt_player_theme];
		$yt_color_show = $_POST[$yt_player_color];
		$yt_vol_show = $_POST[$yt_player_vol];	
}
	else{
		
		$yt_width_show = get_option($yt_player_width);
		$yt_height_show = get_option($yt_player_height);
		$yt_autogo_show = get_option($yt_player_autogo);
		$yt_controls_show_live = get_option($yt_player_controls_live);
		$yt_title_show_live = get_option($yt_player_title_live);
		$yt_autohide_show_live = get_option($yt_player_autohide_live);
		$yt_theme_show = get_option($yt_player_theme);
		$yt_color_show = get_option($yt_player_color);
		$yt_vol_show = get_option($yt_player_vol);
}

		$this->embed_code_on = <<<EOT
<iframe id="$yt_vol_show"
	width="{$yt_width_show}"
	height="{$yt_height_show}"
	src="//www.youtube.com/embed/{$this->live_video_id}?autoplay={$yt_autogo_show}&controls={$yt_controls_show_live}&fs=1&rel=0&showinfo={$yt_title_show_live}&color=$yt_color_show&enablejsapi=1"
	frameborder="0"
	allowfullscreen>
</iframe>
<script>
       var tag = document.createElement('script');

        tag.src = "//www.youtube.com/iframe_api";
        var firstScriptTag = document.getElementsByTagName('script')[0];
        firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

        var player;

        function onYouTubeIframeAPIReady() {
            player = new YT.Player('ytmuteplayerlive', {
                events: {
                    'onReady': onPlayerReady
                }
            });
        }

        function onPlayerReady() {
            player.playVideo();
            player.mute();
        }
	</script>
EOT;

		return $this->embed_code_on;
	}
    
	public function embedCodePlaylist()
	{
	
	$yt_playlist_name = "yt_playlist";
	$yt_player_width = "yt_width";
	$yt_player_height = "yt_height";
	$yt_player_controls = "yt_controls";
	$yt_player_title = "yt_title";
	$yt_player_autohide = "yt_autohide";
	$yt_player_autostart = "yt_autostart";
	$yt_player_theme = "yt_theme";
	$yt_player_color = "yt_color";
    $yt_player_muted = "yt_muted";
 
	if(isset($_POST["get"])){ 
	
		$yt_playlist_show = $_POST[$yt_playlist_name];
    	$yt_width_show = $_POST[$yt_player_width];
    	$yt_height_show = $_POST[$yt_player_height];
    	$yt_controls_show = $_POST[$yt_player_controls];
    	$yt_title_show = $_POST[$yt_player_title];
    	$yt_autohide_show = $_POST[$yt_player_autohide];
		$yt_autostart_show = $_POST[$yt_player_autostart];
		$yt_theme_show = $_POST[$yt_player_theme];
		$yt_color_show = $_POST[$yt_player_color];
        $yt_muted_show = $_POST[$yt_player_muted];
}
	else{
				
		$yt_playlist_show = get_option($yt_playlist_name);
		$yt_width_show = get_option($yt_player_width);
		$yt_height_show = get_option($yt_player_height);
		$yt_controls_show = get_option($yt_player_controls);
		$yt_title_show = get_option($yt_player_title);
		$yt_autohide_show = get_option($yt_player_autohide);
		$yt_autostart_show = get_option($yt_player_autostart);
		$yt_theme_show = get_option($yt_player_theme);
		$yt_color_show = get_option($yt_player_color);
        $yt_muted_show = get_option($yt_player_muted);
}
		$this->embed_code_playlist = <<<EOT
<iframe id="$yt_muted_show" 
	width="{$yt_width_show}"
	height="{$yt_height_show}"
	src="//www.youtube.com/embed/{$this->live_video_id}?list={$yt_playlist_show}&autoplay={$yt_autostart_show}&controls={$yt_controls_show}&fs=1&rel=0&showinfo={$yt_title_show}&color=$yt_color_show&enablejsapi=1"
	frameborder="0"
	allowfullscreen>
</iframe>
<script>
       var tag = document.createElement('script');

        tag.src = "//www.youtube.com/iframe_api";
        var firstScriptTag = document.getElementsByTagName('script')[0];
        firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

        var player;

        function onYouTubeIframeAPIReady() {
            player = new YT.Player('ytmuteplayer', {
                events: {
                    'onReady': onPlayerReady
                }
            });
        }

        function onPlayerReady() {
            player.playVideo();
            player.mute();
        }
	</script>
EOT;
		return $this->embed_code_playlist;
	}
	
	public function embedCodeUploads()
	{
	
	$yt_user_name = "yt_username";
	$yt_api_name = "yt_apikey";
	$yt_player_width = "yt_width";
	$yt_player_height = "yt_height";
	$yt_player_controls = "yt_controls";
	$yt_player_title = "yt_title";
	$yt_player_autohide = "yt_autohide";
	$yt_player_autostart = "yt_autostart";
	$yt_player_theme = "yt_theme";
	$yt_player_color = "yt_color";
    $yt_player_muted = "yt_muted";
 
	if(isset($_POST["get"])){ 
	
		$yt_user_show = $_POST[$yt_user_name];
		$yt_apikey_show = $_POST[$yt_api_name];
    	$yt_width_show = $_POST[$yt_player_width];
    	$yt_height_show = $_POST[$yt_player_height];
    	$yt_controls_show = $_POST[$yt_player_controls];
    	$yt_title_show = $_POST[$yt_player_title];
    	$yt_autohide_show = $_POST[$yt_player_autohide];
		$yt_autostart_show = $_POST[$yt_player_autostart];
		$yt_theme_show = $_POST[$yt_player_theme];
		$yt_color_show = $_POST[$yt_player_color];
        $yt_muted_show = $_POST[$yt_player_muted];
}
	else{
				
		$yt_user_show = get_option($yt_user_name);
		$yt_apikey_show = get_option($yt_api_name);
		$yt_width_show = get_option($yt_player_width);
		$yt_height_show = get_option($yt_player_height);
		$yt_controls_show = get_option($yt_player_controls);
		$yt_title_show = get_option($yt_player_title);
		$yt_autohide_show = get_option($yt_player_autohide);
		$yt_autostart_show = get_option($yt_player_autostart);
		$yt_theme_show = get_option($yt_player_theme);
		$yt_color_show = get_option($yt_player_color);
        $yt_muted_show = get_option($yt_player_muted);
}

$ytlid = NULL;
$inchannel_id = $yt_user_show;

$xml = simplexml_load_file(sprintf('https://www.youtube.com/feeds/videos.xml?channel_id=%s', $inchannel_id));

if (!empty($xml->entry[0]->children('yt', true)->videoId[0])){
    $ytlid = $xml->entry[0]->children('yt', true)->videoId[0];
}

		$this->embed_code_uploads = <<<EOT
	
	<iframe id="$yt_muted_show" width="$yt_width_show" height="$yt_height_show" src="https://www.youtube.com/embed/$ytlid?autoplay={$yt_autostart_show}&controls={$yt_controls_show}&fs=1&rel=0&showinfo={$yt_title_show}&color=$yt_color_show&enablejsapi=1" frameborder="0" allowfullscreen></iframe>
	<script>
       var tag = document.createElement('script');

        tag.src = "//www.youtube.com/iframe_api";
        var firstScriptTag = document.getElementsByTagName('script')[0];
        firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

        var player;

        function onYouTubeIframeAPIReady() {
            player = new YT.Player('ytmuteplayer', {
                events: {
                    'onReady': onPlayerReady
                }
            });
        }

        function onPlayerReady() {
            player.playVideo();
            player.mute();
        }
	</script>
EOT;
		return $this->embed_code_uploads;
	}
	
}
?>