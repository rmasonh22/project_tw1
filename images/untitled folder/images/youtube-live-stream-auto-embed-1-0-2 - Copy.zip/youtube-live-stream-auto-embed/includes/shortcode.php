<?php

require_once('yt-live-player.php');

	$yt_channel_name = "yt_channel";
	$yt_api_name = "yt_apikey";
	$yt_player_switch = "yt_switch";
	$yt_player_style = "yt_style";
 
	if(isset($_POST["get"])){ 
	
    	$yt_channel_show = $_POST[$yt_channel_name];
    	$yt_apikey_show = $_POST[$yt_api_name];
		$yt_switch_show = $_POST[$yt_player_switch];
    	$yt_style_show = $_POST[$yt_player_style];
}
	else{
		
    	$yt_channel_show = get_option($yt_channel_name);
		$yt_apikey_show = get_option($yt_api_name);
		$yt_switch_show = get_option($yt_player_switch);
		$yt_style_show = get_option($yt_player_style);
}

$YouTubeLive = new YouTubeLiveStreamAutoEmbed($yt_channel_show,$yt_apikey_show);
if(!$YouTubeLive->isLive)
{
	echo '<div class="'.$yt_style_show.'">';
	echo $YouTubeLive->$yt_switch_show();
	echo '</div>';
}
else
{
	echo '<div class="'.$yt_style_show.'">';
	echo $YouTubeLive->embedCodeOn();
	echo '</div>';
}
?>