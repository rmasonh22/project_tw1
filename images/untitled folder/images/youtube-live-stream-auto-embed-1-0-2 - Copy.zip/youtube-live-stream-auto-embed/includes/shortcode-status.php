<?php

require_once('yt-live-player-status.php');

	$yt_channel_name = "yt_channel";
	$yt_api_name = "yt_apikey";
	$yt_status1_name = "yt_status1";
	$yt_status2_name = "yt_status2";
 
	if(isset($_POST["get"])){ 
	
    	$yt_channel_show = $_POST[$yt_channel_name];
    	$yt_apikey_show = $_POST[$yt_api_name];
		$yt_status1_show = $_POST[$yt_status1_name];
		$yt_status2_show = $_POST[$yt_status2_name];
}
	else{
		
    	$yt_channel_show = get_option($yt_channel_name);
		$yt_apikey_show = get_option($yt_api_name);
		$yt_status1_show = get_option($yt_status1_name);
		$yt_status2_show = get_option($yt_status2_name);
}

$YouTubeLive = new YouTubeLiveStreamAutoEmbedStatus($yt_channel_show,$yt_apikey_show);
if(!$YouTubeLive->isLive)
{
	echo $YouTubeLive->embedCodeLiveOff();
	echo do_shortcode( stripslashes($yt_status2_show) );
}
else
{
	echo $YouTubeLive->embedCodeLiveOn();
	echo do_shortcode( stripslashes($yt_status1_show) );
}
?>